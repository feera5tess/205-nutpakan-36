//
//  ContentView.swift
//  My-Portrait
//
//  Created by student on 26/8/2566 BE.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack{
            Color.yellow
                .opacity(0.3)
            
            RoundedRectangle(cornerRadius: 200)
                .foregroundColor(Color.black)
                .frame(width: 320, height: 500)
                .offset(y: 50)
            Rectangle()
                .frame(width: 80, height: 200)
                .foregroundStyle(Color.brown)
                .offset(y: 200)
            Capsule()
                .frame(width: 250, height: 300)
                .foregroundStyle(Color.brown)
                .shadow(radius: 100)
            Circle()
                .frame(width: 35)
                .offset(x: -50)
                .foregroundStyle(Color.white)
            Circle()
                .frame(width: 35)
                .offset(x: 50)
                .foregroundStyle(Color.white)
            Circle()
                .frame(width: 15)
                .offset(x: 55)
            Circle()
                .frame(width: 15)
                .offset(x: -55)
            RoundedRectangle(cornerRadius: 70)
                .foregroundColor(Color.blue)
                .frame(width: 300, height: 300)
                .offset(y: 350)
            Circle()
                .trim(from: 0.5 ,to: 1.0)
                .frame(width: 275)
                .offset(y: -20)
                
        }.ignoresSafeArea()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
