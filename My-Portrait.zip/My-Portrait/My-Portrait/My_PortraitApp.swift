//
//  My_PortraitApp.swift
//  My-Portrait
//
//  Created by student on 26/8/2566 BE.
//

import SwiftUI

@main
struct My_PortraitApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
